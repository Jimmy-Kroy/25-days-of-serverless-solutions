Build and run a production-style AI agent in C# using Azure AI Foundry Agent Service.
The sample creates an agent with function tools (hotel & restaurant lookups), keeps a stateful thread for context, and includes robust handling for tool-call de-duplication, RBAC, and auth.

This repo accompanies the blog post on building agentic apps in Azure AI Foundry with C#.

Medium: https://medium.com/@divyeshgovardhanan/azure-ai-foundry-agent-service-c-build-production-ready-ai-agents-f1d3afb0f90a

**Features**
1. Agent Service: threads, messages, runs, function tools
2. C# console app with interactive prompt (stateful conversation)
3. Tool calling: search_hotels, find_restaurants (stubbed; replace with your APIs)
4. De-duped tool outputs to avoid 400 Duplicate call_ids
5. Flexible auth: Service Principal (ClientSecretCredential) or dev chain (DefaultAzureCredential)
6. Enterprise-ready tips: RBAC roles, troubleshooting, model/router notes

**Prerequisites**
1. .NET 8 SDK or later
1. Azure subscription with access to Azure AI Foundry (ai.azure.com)
1. A deployed model (e.g., gpt-4o-mini or your gpt-5 deployment) in your Foundry project

**Nuget Packages:**
dotnet add package Azure.Identity
dotnet add package Azure.AI.Agents.Persistent --prerelease

**Run**
dotnet run

