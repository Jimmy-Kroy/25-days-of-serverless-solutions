﻿// Program.cs
// Console travel-planner agent for Azure AI Foundry Agent Service
// - Creates one agent and one thread (context preserved)
// - Uses function tools (search_hotels, find_restaurants)
// - Handles tool-call submission with de-duplication
// - Flexible auth: Service Principal if AZURE_* are set, else DefaultAzureCredential

using System.Collections.Concurrent;
using System.Text.Json;
using Azure.AI.Agents.Persistent;
using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Configuration;

class Program
{
    static void Main()
    {
        var config = new ConfigurationBuilder()
       .AddJsonFile("appsettings.json", optional: true)
       .AddUserSecrets<Program>(optional: true)
       .Build();

        // --- Config & Auth
        var endpoint = config["endpoint"];
        var model = config["model"];

        TokenCredential credential = BuildCredential();
        var client = new PersistentAgentsClient(endpoint, credential);

        // --- Define function tools (use ctor-with-parameters for SDK compatibility)
        var searchHotelsTool = new FunctionToolDefinition(
            name: "search_hotels",
            description: "Search hotels by city and dates",
            parameters: BinaryData.FromObjectAsJson(new
            {
                type = "object",
                properties = new
                {
                    location = new { type = "string", description = "City, Country" },
                    check_in = new { type = "string", description = "YYYY-MM-DD" },
                    check_out = new { type = "string", description = "YYYY-MM-DD" },
                    guests = new { type = "integer" },
                    budget_max = new { type = "number" }
                },
                required = new[] { "location", "check_in", "check_out", "guests" }
            })
        );

        var findRestaurantsTool = new FunctionToolDefinition(
            name: "find_restaurants",
            description: "Find restaurants by cuisine and price range",
            parameters: BinaryData.FromObjectAsJson(new
            {
                type = "object",
                properties = new
                {
                    location = new { type = "string" },
                    cuisine_type = new { type = "string" },
                    price_range = new { type = "string", description = "$, $$, $$$" }
                }
            })
        );

        // --- Create agent (requires Azure AI data-plane role, e.g., Azure AI User / Project Manager)
        PersistentAgent agent = client.Administration.CreateAgent(
            model: model,
            name: "Travel Planner",
            instructions:
                "You are a travel planning assistant. Ask clarifying questions, then recommend hotels, restaurants, and activities within budget.",
            tools: new List<ToolDefinition> { searchHotelsTool, findRestaurantsTool }
        );

        // --- Create single thread (preserve context across messages)
        PersistentAgentThread thread = client.Threads.CreateThread();

        Console.WriteLine("Travel Planner (type 'exit' to quit)");
        Console.WriteLine("------------------------------------");

        var printedMessageIds = new HashSet<string>();

        while (true)
        {
            Console.Write("\nYou: ");
            var input = Console.ReadLine();
            if (input is null) continue;
            if (input.Trim().Equals("exit", StringComparison.OrdinalIgnoreCase)) break;
            if (string.IsNullOrWhiteSpace(input)) continue;

            // Add user message to thread
            client.Messages.CreateMessage(
                threadId: thread.Id,
                role: MessageRole.User,
                content: input
            );

            // Run the agent (object overload avoids assistantId/agentId naming differences)
            ThreadRun run = client.Runs.CreateRun(
                thread: thread,
                agent: agent
            );

            // Poll and handle tool-calls (with de-duplication)
            WaitForRunCompletion(client, thread, ref run);

            // Print only new assistant messages
            foreach (var m in client.Messages.GetMessages(thread.Id, order: ListSortOrder.Ascending))
            {
                if (m.Role != MessageRole.Agent || printedMessageIds.Contains(m.Id)) continue;

                foreach (var part in m.ContentItems)
                {
                    if (part is MessageTextContent t) Console.WriteLine($"\nAssistant: {t.Text}");
                    else Console.WriteLine($"\nAssistant: {part}");
                }
                printedMessageIds.Add(m.Id);
            }
        }
    }

    // Track which call_ids we've already submitted per run
    static readonly ConcurrentDictionary<string, HashSet<string>> SubmittedByRun =
        new ConcurrentDictionary<string, HashSet<string>>();

    static void WaitForRunCompletion(PersistentAgentsClient client, PersistentAgentThread thread, ref ThreadRun run)
    {
        while (run.Status == RunStatus.Queued || run.Status == RunStatus.InProgress || run.Status == RunStatus.RequiresAction)
        {
            if (run.Status == RunStatus.RequiresAction)
            {
                var pending = GetPendingFunctionCalls(run)
                    .Where(c => !AlreadySubmitted(c.Id, c.Id))
                    .ToList();

                if (pending.Count > 0)
                {
                    var outputs = new List<ToolOutput>(pending.Count);
                    foreach (var call in pending)
                    {
                        var resultJson = HandleFunction(call.Name, call.Arguments.ToString());
                        outputs.Add(new ToolOutput(call.Id, resultJson));
                    }

                    client.Runs.SubmitToolOutputsToRun(thread.Id, run.Id, outputs);
                    MarkSubmitted(run.Id, pending.Select(c => c.Id));
                }
            }

            Thread.Sleep(300);
            run = client.Runs.GetRun(thread.Id, run.Id);
        }

        if (run.Status != RunStatus.Completed && run.LastError is not null)
            Console.WriteLine($"\n[Run Error] {run.LastError.Message}");
    }

    static IEnumerable<RequiredFunctionToolCall> GetPendingFunctionCalls(ThreadRun run)
    {
        // Normalize current + legacy SDK shapes into one unique list
        var seen = new HashSet<string>();

        if (run.RequiredAction is SubmitToolOutputsAction submit && submit.ToolCalls is not null)
        {
            foreach (var call in submit.ToolCalls.OfType<RequiredFunctionToolCall>())
                if (seen.Add(call.Id)) yield return call;
        }

        if (run.RequiredActions is not null)
        {
            foreach (var call in run.RequiredActions) // older previews
                if (seen.Add(call.Id)) yield return call;
        }
    }

    static bool AlreadySubmitted(string runId, string callId)
        => SubmittedByRun.TryGetValue(runId, out var set) && set.Contains(callId);

    static void MarkSubmitted(string runId, IEnumerable<string> callIds)
    {
        var set = SubmittedByRun.GetOrAdd(runId, _ => new HashSet<string>());
        foreach (var id in callIds) set.Add(id);
    }

    // ===== Tool handlers (replace stubs with your real APIs) =====

    static string HandleFunction(string name, string argsJson) =>
        name switch
        {
            "search_hotels" => SearchHotels(argsJson),
            "find_restaurants" => FindRestaurants(argsJson),
            _ => JsonSerializer.Serialize(new { error = $"Unknown tool: {name}" })
        };

    static string SearchHotels(string argsJson)
    {
        var args = JsonDocument.Parse(argsJson).RootElement;
        string location = args.GetProperty("location").GetString()!;
        decimal budget = args.TryGetProperty("budget_max", out var b) ? b.GetDecimal() : 9999m;

        // TODO: call your real search API. This is a stub payload.
        var payload = new
        {
            top_picks = new[]
            {
                new { name = "Hotel Niwa Tokyo",  nightly = 185, area = "Chiyoda"  },
                new { name = "Shinjuku Granbell", nightly = 160, area = "Shinjuku" },
                new { name = "Akasaka Excel",     nightly = 195, area = "Akasaka"  }
            },
            filtered_by = new { location, budget_max = budget }
        };
        return JsonSerializer.Serialize(payload);
    }

    static string FindRestaurants(string argsJson)
    {
        var args = JsonDocument.Parse(argsJson).RootElement;
        string location = args.GetProperty("location").GetString()!;
        string cuisine = args.TryGetProperty("cuisine_type", out var c) ? c.GetString() ?? "" : "";
        string price = args.TryGetProperty("price_range", out var p) ? p.GetString() ?? "" : "";

        var payload = new
        {
            results = new[]
            {
                new { name = "Ichiran Ramen",  cuisine = "Ramen",   price = "$$",  area = "Shinjuku" },
                new { name = "Tempura Kondo",  cuisine = "Tempura", price = "$$$", area = "Ginza"    },
                new { name = "Toriki",         cuisine = "Yakitori",price = "$$",  area = "Koto"     }
            },
            filtered_by = new { location, cuisine_type = cuisine, price_range = price }
        };
        return JsonSerializer.Serialize(payload);
    }

    // ===== Utilities =====

    static TokenCredential BuildCredential()
    {
        // Prefer service principal if all three vars are present
        var tenant = Environment.GetEnvironmentVariable("AZURE_TENANT_ID");
        var clientId = Environment.GetEnvironmentVariable("AZURE_CLIENT_ID");
        var secret = Environment.GetEnvironmentVariable("AZURE_CLIENT_SECRET");

        if (!string.IsNullOrWhiteSpace(tenant) &&
            !string.IsNullOrWhiteSpace(clientId) &&
            !string.IsNullOrWhiteSpace(secret))
        {
            return new ClientSecretCredential(tenant, clientId, secret);
        }

        // Otherwise, use dev chain and ignore partial/bad env creds
        return new DefaultAzureCredential(new DefaultAzureCredentialOptions
        {
            ExcludeEnvironmentCredential = true,
            ExcludeManagedIdentityCredential = true // set false if running in Azure with MSI
        });
    }
}
